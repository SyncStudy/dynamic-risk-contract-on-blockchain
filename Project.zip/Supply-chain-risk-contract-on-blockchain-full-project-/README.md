# Supply chain risk contract on blockchain full project 
 Supply chain risk contract on blockchain 
